package se.dsektionen.nfckeypressemulator

import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.os.Handler
import android.os.Vibrator
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebViewClient
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*
import kotlin.experimental.and


class MainActivity() : AppCompatActivity(), Nfc.NfcActivity {

    var nfc: Nfc? = null

    // Konverterar bytes till hexadecimal
    /*fun bytesToHex(bytes: ByteArray): String {
        val hexChars = CharArray(bytes.size * 2)
        for (j in bytes.indices) {
            val v = bytes[j] and 0xFF
            hexChars[j * 2] = hexArray[v.ushr(4)]
            hexChars[j * 2 + 1] = hexArray[v and 0x0F]
        }

        return String(hexChars)
    }*/

    // Används för att då fram rätt kort-id:n som ligger lagrade som en bakvänd hex-sträng
    /*internal fun bin2int(data: ByteArray): String {
        val reverse = ByteArray(data.size)

        for (i in data.indices) {
            reverse[data.size - i - 1] = data[i]
        }

        return java.lang.Long.toString(java.lang.Long.valueOf(bytesToHex(reverse), 16))
    }*/

    private fun ByteArrayToHexString(arr: ByteArray): String {
        var hex = false
        var reverse = true

        var ubyteArray = arr.asUByteArray()

        if (reverse) ubyteArray = ubyteArray.reversedArray()

        var uint: UInt = ubyteArray.fold(0.toUInt()) { acc: UInt, byte -> (acc shl 8) + byte.toUInt() }

        return uint.toString(if (hex) 16 else 10)
    }

    override fun nfcUpdated(first: Boolean) {
        var nfcEnabled = nfc!!.isEnabled()

        if (nfcEnabled && !first)
            Snackbar
                .make(webView, "NFC is now enabled", Snackbar.LENGTH_SHORT)
                .show()
        else if (!nfcEnabled)
            Snackbar
                .make(webView, "NFC is disabled", Snackbar.LENGTH_INDEFINITE)
                .setAction("Enable NFC", null)
                .show()

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        nfc = Nfc(this, this)

        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("https://medlem.d-sektionen.se/blipp")
        fab.setOnClickListener { view ->
            webView.loadUrl("https://medlem.d-sektionen.se/blipp")

        }

        nfcUpdated(true)
    }

    private fun dispatchKeyEvents(keys: List<Int>) {
        // Recursively fires the keyboard events to show the characters on screen and
        // give the user a feel for what the app is actually doing.

        webView.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keys[0]))
        webView.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keys[0]))

        if (keys.size > 1) {
            Handler().postDelayed({
                dispatchKeyEvents(keys.subList(1, keys.size))
            }, 10)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action) {

            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)

            val rfid = ByteArrayToHexString(tag.id)

            dispatchKeyEvents( KeyCodeUtil.stringToKeyCodeList(rfid+'\n'))

            Log.d("Demo", rfid)
        }
    }


    override fun onResume() {
        super.onResume()

        nfc!!.enableForeground()
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
