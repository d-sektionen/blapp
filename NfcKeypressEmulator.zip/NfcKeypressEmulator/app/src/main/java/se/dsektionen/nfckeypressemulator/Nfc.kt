package se.dsektionen.nfckeypressemulator

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.NfcManager
import android.util.Log

class Nfc(
    private var activity: Activity,
    private var nfcActivity: NfcActivity
) {
    private var nfcManager = activity.getSystemService(Context.NFC_SERVICE) as NfcManager
    private var nfcAdapter = nfcManager.defaultAdapter

    //private var intentFiltersArray: Array<IntentFilter>
    private var intent: PendingIntent
    //private var techListsArray: Array<Array<String>>


    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return;
            val action = intent.action

            if (action == NfcAdapter.ACTION_ADAPTER_STATE_CHANGED) {
                val state = intent.getIntExtra(
                    NfcAdapter.EXTRA_ADAPTER_STATE,
                    NfcAdapter.STATE_OFF
                )
                when (state) {
                    NfcAdapter.STATE_OFF -> nfcActivity.nfcUpdated()
                    NfcAdapter.STATE_ON -> nfcActivity.nfcUpdated()
                }
            }
        }
    }
    init {
        val filter = IntentFilter(NfcAdapter.ACTION_ADAPTER_STATE_CHANGED)
        activity.registerReceiver(broadcastReceiver, filter)

        intent = PendingIntent.getActivity(
            activity, 0, Intent(
                activity,
                activity.javaClass
            ).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0
        )
        val tag = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
        val ndef = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)

        try {
            ndef.addDataType("*/*")
        } catch (e: IntentFilter.MalformedMimeTypeException) {
            throw RuntimeException("Unable to speciy */* Mime Type", e)
        }

        //intentFiltersArray = arrayOf(ndef, tag)

        //techListsArray = arrayOf(arrayOf(NfcA::class.java.name))
    }

    fun isEnabled() : Boolean {
        return nfcAdapter != null && nfcAdapter.isEnabled
    }


    fun enableForeground() {
        Log.d("Demo", "Foregorund enabled")
        nfcAdapter.enableForegroundDispatch(activity, intent, null, null)
    }

    fun disableForeground() {
        Log.d("Demo", "Foregorund disabled")

        nfcAdapter.disableForegroundDispatch(activity)
    }



    interface NfcActivity {
        fun nfcUpdated(first: Boolean = false)
    }
}